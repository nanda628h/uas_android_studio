// Top-level build file
plugins {
    alias(libs.plugins.android.application) apply false
    // TIDAK ADA kotlin-android → KARENA KODE JAVA
}