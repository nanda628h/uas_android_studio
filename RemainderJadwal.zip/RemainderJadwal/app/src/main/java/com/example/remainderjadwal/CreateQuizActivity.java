package com.example.remainderjadwal;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class CreateQuizActivity extends AppCompatActivity {
    EditText etTitle, etQ, et0, et1, et2, et3, etCorrect;
    Button btnAddQ, btnSave;
    Quiz current;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_create_quiz);

        // Inisialisasi semua komponen view
        etTitle = findViewById(R.id.etTitle);
        etQ = findViewById(R.id.etQuestion);
        et0 = findViewById(R.id.etOpt0);
        et1 = findViewById(R.id.etOpt1);
        et2 = findViewById(R.id.etOpt2);
        et3 = findViewById(R.id.etOpt3);
        etCorrect = findViewById(R.id.etCorrect);
        btnAddQ = findViewById(R.id.btnAddQuestion);
        btnSave = findViewById(R.id.btnSaveQuiz);

        // Membuat objek kuis baru dengan judul sementara
        current = new Quiz("Untitled");

        // Logika untuk tombol "Tambah Pertanyaan"
        btnAddQ.setOnClickListener(v -> {
            String q = etQ.getText().toString().trim();
            String[] opts = new String[]{
                    et0.getText().toString().trim(),
                    et1.getText().toString().trim(),
                    et2.getText().toString().trim(),
                    et3.getText().toString().trim()
            };
            int idx;
            try {
                idx = Integer.parseInt(etCorrect.getText().toString().trim());
            } catch (Exception e) {
                idx = -1; // Set ke nilai tidak valid jika input kosong/salah
            }

            // Validasi input pertanyaan
            if (q.isEmpty()) {
                Toast.makeText(this, "Isi kolom pertanyaan", Toast.LENGTH_SHORT).show();
                return;
            }
            if (opts[0].isEmpty() || opts[1].isEmpty() || opts[2].isEmpty() || opts[3].isEmpty()) {
                Toast.makeText(this, "Semua pilihan jawaban harus diisi", Toast.LENGTH_SHORT).show();
                return;
            }
            if (idx < 0 || idx > 3) {
                Toast.makeText(this, "Index jawaban harus antara 0 dan 3", Toast.LENGTH_SHORT).show();
                return;
            }

            // Menambahkan pertanyaan ke objek 'current'
            current.addQuestion(new Question(q, opts, idx));

            // Mengosongkan field setelah pertanyaan ditambahkan
            etQ.setText("");
            et0.setText("");
            et1.setText("");
            et2.setText("");
            et3.setText("");
            etCorrect.setText("");

            Toast.makeText(this, "Pertanyaan ditambahkan (" + current.getQuestions().size() + ")", Toast.LENGTH_SHORT).show();
        });

        // Logika untuk tombol "Simpan Quiz"
        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();

            // 1. Validasi Judul
            if (title.isEmpty()) {
                Toast.makeText(this, "Judul kuis tidak boleh kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            // 2. Validasi Jumlah Pertanyaan
            if (current.getQuestions().isEmpty()) {
                Toast.makeText(this, "Tambahkan minimal 1 pertanyaan", Toast.LENGTH_SHORT).show();
                return;
            }

            // 3. Mengatur Judul (TIDAK membuat objek baru)
            current.setTitle(title);

            // 4. Proses Penyimpanan
            ArrayList<Quiz> list = QuizStorage.getQuizzes(this);
            if (list == null) {
                list = new ArrayList<>();
            }
            list.add(current);
            QuizStorage.saveQuizzes(this, list);

            Toast.makeText(this, "Kuis '" + title + "' berhasil disimpan", Toast.LENGTH_LONG).show();
            finish(); // Menutup halaman
        });
    }
}
