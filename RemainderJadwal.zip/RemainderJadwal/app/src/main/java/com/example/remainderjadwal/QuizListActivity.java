package com.example.remainderjadwal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class QuizListActivity extends AppCompatActivity {
    ListView lv;
    ArrayList<Quiz> quizzes;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_quiz_list);
        Button btnCreate = findViewById(R.id.btnCreate);
        lv = findViewById(R.id.lvQuizzes);

        btnCreate.setOnClickListener(v -> startActivity(new Intent(this, CreateQuizActivity.class)));

        refreshList();
        lv.setOnItemClickListener((parent, view, position, id) -> {
            Quiz q = quizzes.get(position);
            Intent i = new Intent(this, TakeQuizActivity.class);
            i.putExtra("quiz", q);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    private void refreshList() {
        quizzes = QuizStorage.getQuizzes(this);
        String[] titles = new String[quizzes.size()];
        for (int i=0;i<quizzes.size();i++) titles[i] = quizzes.get(i).getTitle() + " (" + quizzes.get(i).getQuestions().size() + " soal)";
        lv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titles));
    }
}
