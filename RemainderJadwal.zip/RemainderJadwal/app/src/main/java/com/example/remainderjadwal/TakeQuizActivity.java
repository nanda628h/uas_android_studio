package com.example.remainderjadwal;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class TakeQuizActivity extends AppCompatActivity {

    Quiz quiz;
    TextView tvTitle, tvQuestion;
    RadioGroup rg;
    Button btnNext;
    int index = 0;
    int score = 0;
    ArrayList<Integer> selected = new ArrayList<>();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_take_quiz);

        tvTitle = findViewById(R.id.tvTitle);
        tvQuestion = findViewById(R.id.tvQuestion);
        rg = findViewById(R.id.rgOptions);
        btnNext = findViewById(R.id.btnNext);

        quiz = (Quiz) getIntent().getSerializableExtra("quiz");
        if (quiz == null) { finish(); return; }

        tvTitle.setText(quiz.getTitle());
        for (int i=0;i<quiz.getQuestions().size();i++) selected.add(-1);
        showQuestion();

        btnNext.setOnClickListener(v -> {
            int sel = -1;
            int childCount = rg.getChildCount();
            for (int i=0;i<childCount;i++) {
                RadioButton rb = (RadioButton) rg.getChildAt(i);
                if (rb.isChecked()) { sel = i; break; }
            }
            selected.set(index, sel);
            // check correctness
            if (sel == quiz.getQuestions().get(index).getCorrectIndex()) score += 10;

            index++;
            if (index < quiz.getQuestions().size()) {
                showQuestion();
            } else {
                // finish -> show result
                Toast.makeText(this, "Quiz selesai. Skor: " + score, Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }

    private void showQuestion() {
        Question q = quiz.getQuestions().get(index);
        tvQuestion.setText((index+1) + ". " + q.getText());
        rg.removeAllViews();
        String[] opts = q.getOptions();
        for (int i=0;i<opts.length;i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(opts[i]);
            rg.addView(rb);
        }
        btnNext.setText(index == quiz.getQuestions().size()-1 ? "Selesai" : "Next");
    }
}
