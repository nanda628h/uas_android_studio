package com.example.remainderjadwal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class AddScheduleActivity extends AppCompatActivity {

    // Deklarasi semua view
    private EditText etDosen, etRuangan, etJam, etCatatan;
    private Spinner spReminder;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule);

        // Inisialisasi view
        etDosen = findViewById(R.id.etDosen);
        etRuangan = findViewById(R.id.etRuangan);
        etJam = findViewById(R.id.etJam);
        etCatatan = findViewById(R.id.etCatatan);
        spReminder = findViewById(R.id.spReminder);
        btnSave = findViewById(R.id.btnSave);

        // Setup Spinner
        String[] reminderOptions = {"Tanpa Pengingat", "10 menit sebelum", "5 menit sebelum"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                reminderOptions
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spReminder.setAdapter(adapter);

        // Tombol Simpan
        btnSave.setOnClickListener(v -> {
            String dosen = etDosen.getText().toString().trim();
            String ruangan = etRuangan.getText().toString().trim();
            String jam = etJam.getText().toString().trim();
            String catatan = etCatatan.getText().toString().trim();

            // Ambil reminder berdasarkan posisi
            int reminderMinutes = 0;
            int selectedPos = spReminder.getSelectedItemPosition();
            if (selectedPos == 1) {
                reminderMinutes = 10;
            } else if (selectedPos == 2) {
                reminderMinutes = 5;
            }

            // Validasi input (opsional, tapi disarankan)
            if (dosen.isEmpty() || ruangan.isEmpty() || jam.isEmpty()) {
                // Bisa tambah Toast atau validasi UI
                return;
            }

            // Buat objek Schedule
            Schedule s = new Schedule(dosen, ruangan, jam, catatan, reminderMinutes);

            // Simpan ke storage
            ArrayList<Schedule> list = ScheduleStorage.getSchedules(this);
            list.add(s);
            ScheduleStorage.saveSchedules(this, list);

            // Jadwalkan alarm jika ada reminder
            if (reminderMinutes > 0) {
                AlarmUtil.scheduleReminder(this, s);
            }

            // Kembali ke activity sebelumnya
            finish();
        });
    }
}