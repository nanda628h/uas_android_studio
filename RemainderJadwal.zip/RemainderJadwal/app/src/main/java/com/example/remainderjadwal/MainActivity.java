package com.example.remainderjadwal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
// Toast sudah tidak diperlukan lagi, jadi kita hapus
// import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Schedule> list;
    private ScheduleAdapter adapter;
    private boolean isDarkMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi view
        RecyclerView rv = findViewById(R.id.rvSchedule);
        ImageButton btnAdd = findViewById(R.id.btnAdd);
        ImageButton btnTheme = findViewById(R.id.btnTheme);
        Button btnQuiz = findViewById(R.id.btnQuiz); // Ini sudah benar

        // Load data dari storage
        list = ScheduleStorage.getSchedules(this);
        if (list == null) {
            list = new ArrayList<>();
        }

        // Setup RecyclerView
        adapter = new ScheduleAdapter(this, list);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        // Tombol Tambah Jadwal
        btnAdd.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddScheduleActivity.class));
        });

        // Tombol Ganti Tema
        btnTheme.setOnClickListener(v -> {
            isDarkMode = !isDarkMode;
            AppCompatDelegate.setDefaultNightMode(
                    isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        // --- INI PERBAIKANNYA ---
        // Tombol Kuis
        btnQuiz.setOnClickListener(v -> {
            // Membuat Intent untuk pindah ke QuizListActivity
            Intent intent = new Intent(MainActivity.this, QuizListActivity.class);
            // Menjalankan Intent untuk membuka halaman tersebut
            startActivity(intent);
        });
        // ------------------------
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data saat kembali dari AddScheduleActivity
        ArrayList<Schedule> updatedList = ScheduleStorage.getSchedules(this);
        if (updatedList != null) {
            list.clear();
            list.addAll(updatedList);
            adapter.notifyDataSetChanged();
        }
    }
}
