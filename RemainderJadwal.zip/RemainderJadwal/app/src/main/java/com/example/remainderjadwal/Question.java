package com.example.remainderjadwal;

import java.io.Serializable;

public class Question implements Serializable {
    private String text;
    private String[] options; // length 4
    private int correctIndex; // 0..3

    public Question(String text, String[] options, int correctIndex) {
        this.text = text;
        this.options = options;
        this.correctIndex = correctIndex;
    }

    public String getText() { return text; }
    public String[] getOptions() { return options; }
    public int getCorrectIndex() { return correctIndex; }
}
