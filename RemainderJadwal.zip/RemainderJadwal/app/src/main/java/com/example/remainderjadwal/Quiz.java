package com.example.remainderjadwal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.UUID;

public class Quiz implements Serializable {
    private String id;
    private String title;
    private ArrayList<Question> questions;

    public Quiz(String title) {
        this.id = UUID.randomUUID().toString();
        this.title = title;
        this.questions = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public ArrayList<Question> getQuestions() { return questions; }
    public void addQuestion(Question q) { questions.add(q); }

    // --- TAMBAHKAN METHOD INI ---
    public void setTitle(String title) {
        this.title = title;
    }
    // ---------------------------
}
